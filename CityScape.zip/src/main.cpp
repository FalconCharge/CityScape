#include "CityScape.h"

int main(int, char**) {
    CityScape cityScape;  // Create the CityScape instance
    cityScape.run();  // Start the main loop
    return 0;  // Exit cleanly
}
