Just making a quick readme 

Use main.cpp to run the cityscape

press P for inverting the camera movement

I also made a change in wolf don't remember what though 
I think it was to do with the camera movement

Another question I have is would it be a good option to create a texture in a upper class then supply that texture to the building class
Like I did with the shader

Ben Harper